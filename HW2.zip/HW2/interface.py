functions = ['1. Show current funds',
             '2. Expenses per month',
             '3. Exit from the program']


def circle_of_options():
    print('Choose option:')
    for item in functions:
        print(item)

