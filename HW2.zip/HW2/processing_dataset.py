bank_numbers = ['720', '480']


def data_processing(filename):
    operations = {}
    with open(filename, 'r', encoding='utf-8') as f:
        for line in f:
            record = line.strip().split(', ')
            if record[0] in bank_numbers:
                key = record[0]
                value = record
                if key not in operations:
                    operations[key] = [value]
                else:
                    operations[key].append(value)
    return operations


a = data_processing('sms.txt')
